import Link from "next/link";
import { ArrowRight, Globe2, UsersRound, MapPin, Headphones } from "lucide-react";

const destinations = [
 {name:"TURKEY", href:"/destinations/turkey", image:"https://images.unsplash.com/photo-1524231757912-21f4fe3a7200?auto=format&fit=crop&w=1200&q=85", text:"Exclusive experiences across unique destinations with Turkey's rich culture, stunning landscapes, and historical treasures."},
 {name:"EUROPE", href:"/destinations/europe", image:"https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1200&q=85", text:"Tailored journeys across Europe with our trusted local network and global standards."},
 {name:"DUBAI", href:"/destinations/dubai", image:"https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=1200&q=85", text:"Discover Dubai's unique blend of tradition, innovation, and luxury."}
];

export default function Home(){
 return <>
  <main>
   <section className="hero">
    <div className="heroBg"/>
    <div className="container heroInner">
      <div className="heroCopy reveal">
        <div className="eyebrow">EXPLORE. CONNECT. INSPIRE.</div>
        <h1 className="serif">Your Best<br/><em>Outgoing Tour</em><br/>Partner</h1>
        <p>Delivering unforgettable travel experiences with trust, innovation and a global perspective.</p>
        <div className="heroBtns"><Link href="/routes" className="btn teal">DISCOVER THE WORLD <ArrowRight size={14}/></Link><Link href="/contact" className="textLink">CONTACT US ↗</Link></div>
      </div>
    </div>
    <div className="scroll">SCROLL TO EXPLORE <span/></div>
    <div className="stats container">
      {[[Globe2,"20+","YEARS OF EXPERIENCE"],[UsersRound,"150+","OFFICIAL PARTNERS"],[MapPin,"1000+","HAPPY TRAVELERS"],[Headphones,"24/7","SUPPORT"]].map(([Icon,num,label],i)=><div className="stat" key={i}><Icon size={25}/><div><strong>{num as string}</strong><small>{label as string}</small></div></div>)}
    </div>
   </section>

   <section className="section light">
    <div className="container">
      <div className="destHead"><div><div className="eyebrow">OUR DESTINATIONS</div><h2 className="section-title">Extraordinary Places,<br/>Unforgettable Experiences</h2></div><p>From historic cities to modern marvels, we bring you the world's most inspiring destinations with unmatched service.</p></div>
      <div className="cards">{destinations.map(d=><Link href={d.href} className="destCard" key={d.name}><img src={d.image}/><div className="cardShade"/><div className="cardText"><span>OUTGOING</span><h3>{d.name}</h3><p>{d.text}</p><b>VIEW DETAILS　→</b></div></Link>)}</div>
    </div>
   </section>

   <section className="about section">
    <div className="container aboutGrid">
      <div><div className="eyebrow">ABOUT US</div><h2 className="section-title">Your Growth<br/>Is Our Mission</h2><p className="section-copy">Outgoing Tour is a trusted business partner for professionals in the tourism industry. By establishing strong partnerships with travel agencies, hotels, tour operators, and other tourism providers, we offer our partners high-quality, customized tour packages worldwide.</p><p className="section-copy">With our extensive range of destinations, flexible options, and personalized approach, we provide B2B partners with high efficiency, reliability, and profitability.</p><Link href="/about" className="btn teal">LEARN MORE ABOUT US →</Link></div>
      <div className="aboutImage"><img src="https://images.unsplash.com/photo-1533104816931-20fa691ff6ca?auto=format&fit=crop&w=1400&q=85"/><div className="promise"><div className="eyebrow">OUR PROMISE</div><p>We don't just plan trips. We craft meaningful experiences that leave lasting impressions.</p></div></div>
    </div>
   </section>

   <section className="section routes">
    <div className="container"><div className="center"><div className="eyebrow">OUR ROUTES</div><h2 className="section-title">Choose Your Journey</h2><p>With every step a discovery, with every route an adventure – a unique travel experience awaits you in our regions.</p></div>
    <div className="routeGrid">{["European Tours","Asia Tours","African Tours","VIP Tours"].map((x,i)=><Link href="/routes" className={"route r"+i} key={x}><span>0{i+1}</span><h3 className="serif">{x}</h3><b>EXPLORE →</b></Link>)}</div></div>
   </section>

   <section className="partners section light"><div className="container center"><div className="eyebrow">OUR PARTNERS</div><h2 className="section-title">Built on Strong Partnerships</h2><div className="logos"><span>Hilton</span><span>Emirates</span><span>Turkish Airlines</span><span>ACCOR</span><span>Marriott</span></div></div></section>

   <section className="cta section"><div className="container ctaBox"><div><div className="eyebrow">LET'S CREATE SOMETHING EXTRAORDINARY</div><h2 className="section-title">Your next journey<br/>starts here.</h2></div><Link href="/contact" className="btn">CONTACT OUR TEAM →</Link></div></section>
  </main>
  <style jsx>{`
   .hero{min-height:760px;position:relative;overflow:visible;padding-top:160px}.heroBg{position:absolute;inset:0;background:linear-gradient(90deg,#06131de8 0%,#06131d9b 45%,#06131d12 100%),url("https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=2200&q=90") center/cover;z-index:-1}.heroInner{min-height:540px;display:flex;align-items:center}.heroCopy{max-width:620px}.heroCopy h1{font-size:clamp(62px,7vw,102px);line-height:.84;font-weight:500;margin:20px 0 28px}.heroCopy h1 em{font-style:normal;color:var(--gold2)}.heroCopy p{max-width:390px;color:#d0d6d8;line-height:1.7}.heroBtns{display:flex;align-items:center;gap:25px;margin-top:30px}.textLink{font-size:10px;letter-spacing:.1em}.scroll{position:absolute;right:35px;top:48%;writing-mode:vertical-rl;font-size:8px;letter-spacing:.2em;color:#a8b2b6}.scroll span{display:block;width:1px;height:55px;background:var(--gold);margin-top:12px}.stats{background:#f6f4ef;color:#10202a;display:grid;grid-template-columns:repeat(4,1fr);padding:25px 30px;position:relative;transform:translateY(50px);box-shadow:0 20px 70px #0005}.stat{display:flex;justify-content:center;gap:16px;align-items:center;border-right:1px solid #d6d3cb}.stat:last-child{border:0}.stat svg{color:var(--teal)}.stat strong{display:block;font:600 32px "Cormorant Garamond"}.stat small{display:block;font-size:8px;letter-spacing:.12em;color:#647076}.destHead{display:grid;grid-template-columns:1.2fr .8fr;gap:50px;align-items:end;margin-bottom:45px}.destHead>p{line-height:1.8;color:#667279;max-width:380px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.destCard{height:470px;position:relative;overflow:hidden;background:#111;border-radius:3px}.destCard img{width:100%;height:100%;object-fit:cover;transition:1s}.destCard:hover img{transform:scale(1.06)}.cardShade{position:absolute;inset:0;background:linear-gradient(transparent 25%,#03111de8 90%)}.cardText{position:absolute;bottom:28px;left:28px;right:25px;color:white}.cardText span{font-size:9px;color:var(--teal);letter-spacing:.16em}.cardText h3{font:600 48px "Cormorant Garamond";margin:2px 0 8px}.cardText p{font-size:11px;line-height:1.6;color:#d2d7d9}.cardText b{font-size:9px;letter-spacing:.08em;border:1px solid #ffffff88;padding:11px 13px;display:inline-block;margin-top:12px}.about{background:#081721}.aboutGrid{display:grid;grid-template-columns:1fr 1fr;gap:70px;align-items:center}.aboutImage{position:relative;min-height:570px}.aboutImage img{width:100%;height:570px;object-fit:cover}.promise{position:absolute;left:-30px;bottom:30px;background:#071823e8;padding:27px;max-width:270px;border:1px solid var(--line);backdrop-filter:blur(10px)}.promise p{line-height:1.6;color:#d0d7d9;font-family:"Cormorant Garamond";font-size:22px}.routes{background:#06131d}.center{text-align:center}.center>p{color:var(--muted);max-width:600px;margin:0 auto 45px;line-height:1.7}.routeGrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.route{min-height:250px;position:relative;padding:22px;display:flex;flex-direction:column;justify-content:flex-end;overflow:hidden;border:1px solid var(--line)}.route:before{content:"";position:absolute;inset:0;background:var(--bg) center/cover;z-index:0;transition:.8s}.route:after{content:"";position:absolute;inset:0;background:linear-gradient(transparent,#06131df0)}.route>*{position:relative;z-index:1}.route span{position:absolute;top:20px;right:20px;color:var(--gold);font-size:10px}.route h3{font-size:28px;margin:0 0 10px}.route b{font-size:9px;letter-spacing:.12em}.r0{--bg:url("https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=900&q=80")}.r1{--bg:url("https://images.unsplash.com/photo-1528360983277-13d401cdc186?auto=format&fit=crop&w=900&q=80")}.r2{--bg:url("https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?auto=format&fit=crop&w=900&q=80")}.r3{--bg:url("https://images.unsplash.com/photo-1544161515-4ab6ce6db874?auto=format&fit=crop&w=900&q=80")}.route:hover:before{transform:scale(1.07)}.logos{display:flex;justify-content:space-between;align-items:center;gap:25px;margin-top:45px;color:#7b858a;font-family:"Cormorant Garamond";font-size:28px}.logos span:nth-child(3){font-size:20px}.cta{background:#081b26}.ctaBox{display:flex;justify-content:space-between;align-items:center;border:1px solid var(--line);padding:65px 70px;background:radial-gradient(circle at 80% 20%,#18b7b118,transparent 35%)}.ctaBox .section-title{margin-bottom:0}@media(max-width:850px){.hero{min-height:820px}.heroInner{align-items:flex-start;padding-top:150px}.stats{grid-template-columns:1fr 1fr;gap:20px}.stat{border:0}.destHead,.aboutGrid{grid-template-columns:1fr}.cards{grid-template-columns:1fr}.destCard{height:430px}.aboutImage,.aboutImage img{min-height:430px;height:430px}.routeGrid{grid-template-columns:1fr 1fr}.logos{flex-wrap:wrap;justify-content:center}.ctaBox{flex-direction:column;align-items:flex-start;gap:25px;padding:40px 30px}}@media(max-width:520px){.heroCopy h1{font-size:58px}.stats{padding:20px 15px}.stat strong{font-size:27px}.routeGrid{grid-template-columns:1fr}.scroll{display:none}.heroBtns{flex-direction:column;align-items:flex-start}.logos{font-size:23px}}
  `}</style>
 </>;
}